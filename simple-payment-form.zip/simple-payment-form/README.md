# Simple payment form 

A Pen created on CodePen.

Original URL: [https://codepen.io/Osei-Patrick-the-selector/pen/MYWrGrB](https://codepen.io/Osei-Patrick-the-selector/pen/MYWrGrB).

