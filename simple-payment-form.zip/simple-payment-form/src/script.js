// Signup Function
function signup() {
    let username = document.getElementById("username").value;
    let password = document.getElementById("password").value;

    if (localStorage.getItem(username)) {
        document.getElementById("message").innerText = "Username already exists!";
    } else {
        localStorage.setItem(username, password);
        localStorage.setItem(username + "_balance", 0);
        document.getElementById("message").innerText = "Account created successfully!";
    }
}

// Login Function
function login() {
    let username = document.getElementById("username").value;
    let password = document.getElementById("password").value;

    if (localStorage.getItem(username) === password) {
        document.getElementById("message").innerText = "Login successful!";
    } else {
        document.getElementById("message").innerText = "Invalid username or password!";
    }
}

// Pay with Paystack
function payWithPaystack() {
    let handler = PaystackPop.setup({
        key: "pk_live_6861af456159bb3961230c088ad9d6536f33db57", // Replace with your Paystack Public Key
        email: "oseipatrick251@gmail.com", // Replace with a real email
        amount: 5000 * 100, // Amount in kobo (5,000 NGN = 50 GHS)
        currency: "GHS",
        ref: 'TX' + Math.floor((Math.random() * 1000000000) + 1),
        callback: function(response) {
            alert('Payment successful! Transaction ref: ' + response.reference);
        },
        onClose: function() {
            alert('Transaction was not completed.');
        },
    });
    handler.openIframe();
}